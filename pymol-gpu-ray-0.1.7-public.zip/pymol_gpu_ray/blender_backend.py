"""Blender/Cycles rendering backend for PyMOL GPU Ray.

This file is launched by Blender, not imported by PyMOL.  Keeping Blender's
Python API on this side of a process boundary makes the PyMOL plugin portable
across bundled Python versions and prevents renderer crashes from taking down
PyMOL.
"""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import re
import sys
import traceback

# Make the sibling fallback COLLADA parser importable when this file is passed
# directly to `blender --python`.
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import bmesh  # type: ignore
import bpy  # type: ignore
from mathutils import Matrix, Vector  # type: ignore

import collada_pymol

MARKER = "PYMOL_GPU_RAY_RESULT="
FOG_AOV = "PyMOL_DepthFog"
FOG_COVERAGE_AOV = "PyMOL_FogCoverage"


def emit(payload: dict) -> None:
    print(MARKER + json.dumps(payload, separators=(",", ":")), flush=True)


def _version_string() -> str:
    return ".".join(str(x) for x in bpy.app.version)


def _cycles_preferences():
    addon = bpy.context.preferences.addons.get("cycles")
    if addon is None:
        raise RuntimeError("Cycles addon is not available in this Blender installation")
    return addon.preferences


def configure_device(requested: str = "AUTO") -> dict:
    """Configure Cycles and return a diagnostic payload.

    AUTO prefers OptiX, then CUDA, then CPU.  Explicit OPTIX/CUDA requests
    fail cleanly if no corresponding device is available instead of silently
    pretending the GPU is in use.
    """
    requested = (requested or "AUTO").upper()
    if requested not in {"AUTO", "OPTIX", "CUDA", "CPU"}:
        raise ValueError(f"Unknown backend {requested!r}; use AUTO, OPTIX, CUDA or CPU")

    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    prefs = _cycles_preferences()

    if requested == "CPU":
        scene.cycles.device = "CPU"
        return {
            "ok": True,
            "requested": requested,
            "backend": "CPU",
            "devices": [{"name": "CPU", "type": "CPU", "enabled": True}],
            "blender": _version_string(),
        }

    attempts = [requested] if requested != "AUTO" else ["OPTIX", "CUDA"]
    errors = []
    for backend in attempts:
        try:
            prefs.compute_device_type = backend
            # Refresh devices after changing the compute backend.
            try:
                prefs.get_devices()
            except Exception:
                pass
            devices = list(getattr(prefs, "devices", []))
            matching = [d for d in devices if str(getattr(d, "type", "")).upper() == backend]
            # Some Blender builds report OPTIX/CUDA devices with type other than
            # the preference token; accept a non-CPU device as a conservative
            # fallback when only one GPU backend has been selected.
            if not matching:
                matching = [d for d in devices if str(getattr(d, "type", "")).upper() != "CPU"]
            if not matching:
                errors.append(f"{backend}: no compatible Cycles device found")
                continue
            for d in devices:
                d.use = d in matching
            scene.cycles.device = "GPU"
            return {
                "ok": True,
                "requested": requested,
                "backend": backend,
                "devices": [
                    {
                        "name": str(getattr(d, "name", "GPU")),
                        "type": str(getattr(d, "type", backend)),
                        "enabled": bool(getattr(d, "use", False)),
                    }
                    for d in devices
                ],
                "blender": _version_string(),
            }
        except Exception as exc:
            errors.append(f"{backend}: {exc}")

    if requested != "AUTO":
        raise RuntimeError("; ".join(errors) or f"{requested} is unavailable")

    scene.cycles.device = "CPU"
    return {
        "ok": True,
        "requested": requested,
        "backend": "CPU",
        "warning": "No OptiX/CUDA device was available; falling back to CPU",
        "errors": errors,
        "devices": [{"name": "CPU", "type": "CPU", "enabled": True}],
        "blender": _version_string(),
    }


def clear_scene() -> None:
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.cameras, bpy.data.lights):
        # Remove orphaned datablocks left by a previous default scene.
        for block in list(datablocks):
            if block.users == 0:
                datablocks.remove(block)


def _axis_conversion(up_axis: str) -> Matrix:
    # PyMOL's COLLADA exporter declares Y_UP. Blender is Z_UP. This is the
    # conventional Y-up -> Z-up conversion: (x, y, z) -> (x, -z, y).
    if up_axis == "Y_UP":
        return Matrix(((1, 0, 0, 0), (0, 0, -1, 0), (0, 1, 0, 0), (0, 0, 0, 1)))
    if up_axis == "X_UP":
        return Matrix(((0, 0, 1, 0), (1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 0, 1)))
    return Matrix.Identity(4)


def _m4(rows) -> Matrix:
    return Matrix(tuple(tuple(float(v) for v in row) for row in rows))


def _option(job: dict, key: str, default: float, low: float, high: float) -> float:
    value = float(job.get(key, default))
    if not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f"{key} must be between {low:g} and {high:g}")
    return value


def _new_material(name: str, color_attr: str | None, opacity: float, saturation: float = 1.0, emission_strength: float = 0.0, roughness: float = 0.34):
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out = nodes.new("ShaderNodeOutputMaterial")
    principled = nodes.new("ShaderNodeBsdfPrincipled")
    principled.inputs["Roughness"].default_value = roughness
    if "Metallic" in principled.inputs:
        principled.inputs["Metallic"].default_value = 0.0
    if "Specular IOR Level" in principled.inputs:
        principled.inputs["Specular IOR Level"].default_value = 0.35
    elif "Specular" in principled.inputs:
        principled.inputs["Specular"].default_value = 0.35

    color_socket = None
    alpha_socket = None
    if color_attr:
        try:
            vc = nodes.new("ShaderNodeVertexColor")
            vc.layer_name = color_attr
            color_socket = vc.outputs.get("Color")
            alpha_socket = vc.outputs.get("Alpha")
        except Exception:
            vc = nodes.new("ShaderNodeAttribute")
            vc.attribute_name = color_attr
            color_socket = vc.outputs.get("Color")
            alpha_socket = vc.outputs.get("Fac")

        hsv = nodes.new("ShaderNodeHueSaturation")
        hsv.inputs["Hue"].default_value = 0.5
        hsv.inputs["Saturation"].default_value = max(0.0, float(saturation))
        hsv.inputs["Value"].default_value = 1.0
        if color_socket is not None:
            links.new(color_socket, hsv.inputs["Color"])
            links.new(hsv.outputs["Color"], principled.inputs["Base Color"])
            if "Emission Color" in principled.inputs:
                links.new(hsv.outputs["Color"], principled.inputs["Emission Color"])
                if "Emission Strength" in principled.inputs:
                    principled.inputs["Emission Strength"].default_value = max(0.0, float(emission_strength))
            elif "Emission" in principled.inputs:
                links.new(hsv.outputs["Color"], principled.inputs["Emission"])
                if "Emission Strength" in principled.inputs:
                    principled.inputs["Emission Strength"].default_value = max(0.0, float(emission_strength))
        if alpha_socket is not None and "Alpha" in principled.inputs:
            links.new(alpha_socket, principled.inputs["Alpha"])
    else:
        principled.inputs["Base Color"].default_value = (0.8, 0.8, 0.8, 1.0)

    opacity = max(0.0, min(1.0, float(opacity)))
    # Material normalization must retain the imported opacity, even after
    # replacing the exporter material name with our own generated name.
    mat.diffuse_color = (0.8, 0.8, 0.8, opacity)
    if opacity >= 0.999:
        links.new(principled.outputs["BSDF"], out.inputs["Surface"])
    else:
        transparent = nodes.new("ShaderNodeBsdfTransparent")
        mix = nodes.new("ShaderNodeMixShader")
        mix.inputs[0].default_value = opacity
        links.new(transparent.outputs["BSDF"], mix.inputs[1])
        links.new(principled.outputs["BSDF"], mix.inputs[2])
        links.new(mix.outputs["Shader"], out.inputs["Surface"])
        try:
            mat.surface_render_method = "DITHERED"
        except Exception:
            pass
    return mat


def _apply_mesh_attributes(mesh, geom: collada_pymol.GeometryData) -> str | None:
    color_name = None
    loop_count = len(mesh.loops)
    if geom.corner_colors and len(geom.corner_colors) == loop_count:
        color_name = "pymol_color"
        try:
            attr = mesh.color_attributes.new(name=color_name, type="FLOAT_COLOR", domain="CORNER")
            for i, rgba in enumerate(geom.corner_colors):
                attr.data[i].color = tuple(float(x) for x in rgba)
        except Exception as exc:
            print(f"[PyMOL GPU Ray] warning: could not attach vertex colors: {exc}", flush=True)
            color_name = None

    # PyMOL's COLLADA normals can preserve hard edges on low-poly spheres and
    # make them look duplicated/faceted. Recompute smooth shading in Blender
    # instead of forcing custom split normals.
    for poly in mesh.polygons:
        poly.use_smooth = True
    return color_name


def _cleanup_mesh(mesh, merge_distance: float = 1e-5) -> None:
    try:
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=float(merge_distance))
        bm.to_mesh(mesh)
        bm.free()
        mesh.update(calc_edges=True)
    except Exception as exc:
        print(f"[PyMOL GPU Ray] warning: could not weld mesh vertices: {exc}", flush=True)



def import_collada_fallback(path: str) -> tuple[list, object | None]:
    data = collada_pymol.parse(path)
    clear_scene()
    conv = _axis_conversion(data.up_axis)
    objects = []

    # Re-use mesh datablocks for repeated geometry instances, but material can
    # differ by instance so create a copy when necessary.
    for i, inst in enumerate(data.instances):
        geom = data.geometries.get(inst.geometry_id)
        if geom is None or not geom.positions or not geom.faces:
            continue
        mesh = bpy.data.meshes.new(f"PyMOL_{inst.geometry_id}_{i}")
        mesh.from_pydata(geom.positions, [], geom.faces)
        mesh.update(calc_edges=True)
        # Attach corner colors before welding. Cleanup can remove degenerate
        # faces and reorder loops; BMesh preserves their attached color data.
        color_name = _apply_mesh_attributes(mesh, geom)
        _cleanup_mesh(mesh, 1e-5)
        opacity = data.materials.get(inst.material_id or "", collada_pymol.MaterialInfo("", 1.0)).opacity
        mesh.materials.append(_new_material(f"PyMOLMaterial_{i}", color_name, opacity))

        obj = bpy.data.objects.new(f"PyMOL_{inst.geometry_id}_{i}", mesh)
        bpy.context.collection.objects.link(obj)
        obj.matrix_world = conv @ _m4(inst.matrix)
        objects.append(obj)

    cam_obj = None
    if data.camera is not None:
        c = data.camera
        cam = bpy.data.cameras.new("PyMOLCamera")
        cam_obj = bpy.data.objects.new("PyMOLCamera", cam)
        bpy.context.collection.objects.link(cam_obj)
        cam_obj.matrix_world = conv @ _m4(c.matrix)
        cam.clip_start = max(1e-4, float(c.znear))
        cam.clip_end = max(cam.clip_start + 1.0, float(c.zfar))
        # PyMOL exports a vertical FOV/orthographic half-height. Keep that
        # framing when the output takes the viewer's current aspect ratio.
        cam.sensor_fit = "VERTICAL"
        if c.perspective:
            cam.type = "PERSP"
            # angle_y is a direct match for COLLADA's yfov.
            try:
                cam.angle_y = math.radians(float(c.yfov_deg))
            except Exception:
                cam.angle = math.radians(float(c.yfov_deg))
        else:
            cam.type = "ORTHO"
            cam.ortho_scale = max(1e-4, 2.0 * float(c.ymag))
        bpy.context.scene.camera = cam_obj

    return objects, cam_obj


def _collada_operator_available() -> bool:
    try:
        # bpy.ops returns a proxy even for unregistered operators, so hasattr
        # falsely reports COLLADA support in Blender 5. Check its RNA instead.
        bpy.ops.wm.collada_import.get_rna_type()
        return True
    except Exception:
        return False


def import_scene(path: str) -> tuple[str, list, object | None]:
    """Import COLLADA, preferring Blender's legacy importer when present."""
    clear_scene()
    if _collada_operator_available():
        try:
            bpy.ops.wm.collada_import(filepath=str(path))
            objects = [o for o in bpy.context.scene.objects if o.type == "MESH"]
            cam = next((o for o in bpy.context.scene.objects if o.type == "CAMERA"), None)
            if cam is not None:
                bpy.context.scene.camera = cam
            return "BLENDER_COLLADA", objects, cam
        except Exception as exc:
            print(f"[PyMOL GPU Ray] Blender COLLADA import failed, using fallback parser: {exc}", flush=True)
    objects, cam = import_collada_fallback(path)
    return "PYMOL_COLLADA", objects, cam


_TRANSPARENCY_RE = re.compile(r"transparency[-_ ]([01](?:\.\d+)?)", re.I)


def _infer_opacity(material) -> float:
    name = str(getattr(material, "name", ""))
    m = _TRANSPARENCY_RE.search(name)
    if m:
        try:
            return max(0.0, min(1.0, 1.0 - float(m.group(1))))
        except ValueError:
            pass
    try:
        return float(material.diffuse_color[3])
    except Exception:
        return 1.0


def normalize_imported_materials(objects: list, saturation: float = 1.0, emission_strength: float = 0.0, roughness: float = 0.34) -> None:
    """Make imported PyMOL colors reliable under modern Cycles.

    Legacy COLLADA importers vary in how they wire vertex colors.  Rebuilding
    the material keeps color fidelity stable across Blender releases.
    """
    for obj in objects:
        if obj.type != "MESH":
            continue
        mesh = obj.data
        color_name = None
        try:
            if len(mesh.color_attributes):
                # Prefer corner-domain colors, which is how PyMOL exports them.
                attrs = list(mesh.color_attributes)
                chosen = next((a for a in attrs if a.domain == "CORNER"), attrs[0])
                color_name = chosen.name
        except Exception:
            pass
        old = mesh.materials[0] if len(mesh.materials) else None
        opacity = _infer_opacity(old) if old is not None else 1.0
        # Zero-opacity shells must not consume Cycles' transparent bounce
        # budget and become visible where many surfaces overlap.
        obj.hide_render = opacity <= 0.0
        mesh.materials.clear()
        mesh.materials.append(_new_material(f"PyMOLCycles_{obj.name}", color_name, opacity, saturation, emission_strength, roughness))
        for poly in mesh.polygons:
            poly.use_smooth = True


def enhance_fallback_materials(objects: list, saturation: float = 1.0, emission_strength: float = 0.0, roughness: float = 0.34) -> None:
    for obj in objects:
        if obj.type != "MESH":
            continue
        mesh = obj.data
        color_name = None
        try:
            if len(mesh.color_attributes):
                attrs = list(mesh.color_attributes)
                chosen = next((a for a in attrs if a.domain == "CORNER"), attrs[0])
                color_name = chosen.name
        except Exception:
            pass
        opacity = 1.0
        if len(mesh.materials):
            opacity = _infer_opacity(mesh.materials[0])
        obj.hide_render = opacity <= 0.0
        mesh.materials.clear()
        mesh.materials.append(_new_material(f"PyMOLCycles_{obj.name}", color_name, opacity, saturation, emission_strength, roughness))


def scene_bounds(objects: list) -> tuple[Vector, float]:
    points = []
    for obj in objects:
        if obj.type != "MESH":
            continue
        mw = obj.matrix_world
        # Bounding-box corners are enough and much cheaper for molecular meshes.
        for corner in obj.bound_box:
            points.append(mw @ Vector(corner))
    if not points:
        return Vector((0.0, 0.0, 0.0)), 10.0
    lo = Vector((min(p.x for p in points), min(p.y for p in points), min(p.z for p in points)))
    hi = Vector((max(p.x for p in points), max(p.y for p in points), max(p.z for p in points)))
    center = (lo + hi) * 0.5
    span = max((hi - lo).length, max(hi.x - lo.x, hi.y - lo.y, hi.z - lo.z), 1.0)
    return center, span


def smooth_spheres(objects: list) -> int:
    """Round individually exported sphere meshes, keeping their corner colors.

    PyMOL can export just 80 triangles per atom. Auto Smooth fixes shading but
    cannot round the outline, so subdivide and project onto the fitted sphere
    before applying it. Do not subdivide ribbons, cylinders, or other geometry.
    """
    count = 0
    for obj in objects:
        if obj.type != "MESH":
            continue
        mesh = obj.data
        if len(mesh.vertices) < 12 or not 20 <= len(mesh.polygons) <= 1280:
            continue
        if any(len(poly.vertices) != 3 for poly in mesh.polygons):
            continue
        center = sum((v.co for v in mesh.vertices), Vector()) / len(mesh.vertices)
        radii = [(v.co - center).length for v in mesh.vertices]
        radius = sum(radii) / len(radii)
        if radius < 1e-6 or max(abs(r - radius) for r in radii) > max(1e-5, radius * 0.001):
            continue
        bm = bmesh.new()
        try:
            bm.from_mesh(mesh)
            if any(not edge.is_manifold for edge in bm.edges):
                continue
            for _ in range(2):
                if len(bm.faces) >= 1280:
                    break
                bmesh.ops.subdivide_edges(bm, edges=list(bm.edges), cuts=1, use_grid_fill=True)
                for vertex in bm.verts:
                    delta = vertex.co - center
                    if delta.length > 1e-8:
                        vertex.co = center + delta.normalized() * radius
            bm.to_mesh(mesh)
        finally:
            bm.free()
        for poly in mesh.polygons:
            poly.use_smooth = True
        for edge in mesh.edges:
            edge.use_edge_sharp = False
        mesh.update()
        mesh.normals_split_custom_set_from_vertices([
            tuple((vertex.co - center).normalized()) for vertex in mesh.vertices
        ])
        try:
            with bpy.context.temp_override(object=obj, active_object=obj,
                                           selected_objects=[obj], selected_editable_objects=[obj]):
                bpy.ops.object.shade_auto_smooth(angle=math.radians(60))
        except (AttributeError, KeyError, RuntimeError):
            # Headless builds without the bundled modifier asset can still
            # apply the same angle-based sharpness directly to the mesh.
            if hasattr(mesh, "set_sharp_from_angle"):
                mesh.set_sharp_from_angle(angle=math.radians(60))
        count += 1
    return count


def setup_depth_of_field(job: dict, objects: list, camera) -> dict:
    dof = camera.data.dof
    dof.use_dof = bool(job.get("dof", False))
    previous_focus = dof.focus_object
    dof.focus_object = None
    if previous_focus is not None and previous_focus.get("pymol_gpu_ray_focus"):
        bpy.data.objects.remove(previous_focus, do_unlink=True)
    if not dof.use_dof:
        return {"enabled": False}
    fstop = float(job.get("fstop", 0.02))
    if not math.isfinite(fstop) or not 0.01 <= fstop <= 128.0:
        raise ValueError("fstop must be between 0.01 and 128")
    dof.aperture_fstop = fstop
    focus_depth = _option(job, "focus_depth", 10.0, 0.0, 100.0)
    bpy.context.view_layer.update()
    camera_position = camera.matrix_world.translation
    forward = camera.matrix_world.to_quaternion() @ Vector((0, 0, -1))
    nearest_point = None
    nearest_depth = float("inf")
    farthest_depth = -float("inf")
    depsgraph = bpy.context.evaluated_depsgraph_get()
    for obj in objects:
        if obj.type != "MESH" or obj.hide_render:
            continue
        evaluated = obj.evaluated_get(depsgraph)
        mesh = evaluated.to_mesh()
        try:
            for vertex in mesh.vertices:
                point = evaluated.matrix_world @ vertex.co
                depth = (point - camera_position).dot(forward)
                if camera.data.clip_start < depth < camera.data.clip_end:
                    farthest_depth = max(farthest_depth, depth)
                    if depth < nearest_depth:
                        nearest_depth, nearest_point = depth, point.copy()
        finally:
            evaluated.to_mesh_clear()
    if nearest_point is None:
        raise RuntimeError("No system surface was found in front of the camera for depth-of-field focus")
    focus = bpy.data.objects.new("PyMOL_DOF_Focus", None)
    bpy.context.collection.objects.link(focus)
    focus.empty_display_type = "PLAIN_AXES"
    focus.empty_display_size = max(0.1, scene_bounds(objects)[1] * 0.015)
    # Move back into the molecule by a fraction of its own depth, not of the
    # much larger camera distance. This makes 10% consistent across zoom levels.
    inset = (farthest_depth - nearest_depth) * focus_depth / 100.0
    focus.location = nearest_point + forward * inset
    focus.hide_render = True
    focus["pymol_gpu_ray_focus"] = True
    dof.focus_object = focus
    dof.focus_distance = nearest_depth + inset
    return {"enabled": True, "fstop": fstop, "focus_object": focus.name,
            "focus_point": list(focus.location), "focus_distance": nearest_depth + inset,
            "focus_depth": focus_depth, "front_distance": nearest_depth, "back_distance": farthest_depth}


def point_light(obj, target: Vector) -> None:
    direction = target - obj.location
    if direction.length > 1e-8:
        obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()


def add_lighting(objects: list, camera, bg_rgb, transparent: bool, job: dict | None = None) -> None:
    job = job or {}
    angle = math.radians(_option(job, "light_angle", 0.0, -180.0, 180.0))
    softness = _option(job, "shadow_softness", 1.0, 0.25, 3.0)
    fill = _option(job, "fill_light", 1.0, 0.0, 3.0)
    # Remove lights imported from COLLADA so lighting is deterministic.
    for obj in list(bpy.context.scene.objects):
        if obj.type == "LIGHT":
            bpy.data.objects.remove(obj, do_unlink=True)

    center, span = scene_bounds(objects)
    if camera is not None:
        cm = camera.matrix_world
        right = cm.to_quaternion() @ Vector((1, 0, 0))
        up = cm.to_quaternion() @ Vector((0, 1, 0))
        back = cm.to_quaternion() @ Vector((0, 0, 1))
    else:
        right, up, back = Vector((1, 0, 0)), Vector((0, 0, 1)), Vector((0, -1, 0))
    right, up = (right * math.cos(angle) + up * math.sin(angle),
                 up * math.cos(angle) - right * math.sin(angle))

    # A soft studio key, restrained fill and rim give form on light slides.
    # Scale wattage with distance squared so scene size does not change the look.
    rigs = [
        ("Key", center - right * span * 0.55 + up * span * 0.65 + back * span * 0.60, 3000.0, 0.45),
        ("Fill", center + right * span * 0.65 + up * span * 0.10 + back * span * 0.35, 550.0, 0.65),
        ("Rim", center + right * span * 0.30 + up * span * 0.40 - back * span * 0.55, 1600.0, 0.35),
    ]
    power_scale = (span / 20.0) ** 2
    for name, location, base_power, size_factor in rigs:
        lamp = bpy.data.lights.new(name, type="AREA")
        lamp.energy = base_power * power_scale * (fill if name == "Fill" else 1.0)
        lamp.shape = "DISK"
        lamp.size = max(span * 0.005, span * size_factor * softness)
        obj = bpy.data.objects.new(name, lamp)
        bpy.context.collection.objects.link(obj)
        obj.location = location
        point_light(obj, center)

    world = bpy.context.scene.world or bpy.data.worlds.new("PyMOLWorld")
    bpy.context.scene.world = world
    world.use_nodes = True
    nodes, links = world.node_tree.nodes, world.node_tree.links
    nodes.clear()
    lighting = nodes.new("ShaderNodeBackground")
    lighting.inputs["Color"].default_value = (0.8, 0.8, 0.8, 1.0)
    lighting.inputs["Strength"].default_value = 0.06
    backdrop = nodes.new("ShaderNodeBackground")
    rgb = [max(0.0, min(1.0, float(x))) for x in bg_rgb[:3]]
    backdrop.inputs["Color"].default_value = (*rgb, 1.0)
    backdrop.inputs["Strength"].default_value = 1.0
    light_path = nodes.new("ShaderNodeLightPath")
    mix = nodes.new("ShaderNodeMixShader")
    output = nodes.new("ShaderNodeOutputWorld")
    links.new(light_path.outputs["Is Camera Ray"], mix.inputs[0])
    links.new(lighting.outputs["Background"], mix.inputs[1])
    links.new(backdrop.outputs["Background"], mix.inputs[2])
    links.new(mix.outputs["Shader"], output.inputs["Surface"])



def setup_render(job: dict) -> None:
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.render.resolution_x = int(job.get("width", 1920))
    scene.render.resolution_y = int(job.get("height", 1080))
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA" if job.get("transparent", True) else "RGB"
    scene.render.film_transparent = bool(job.get("transparent", True))
    scene.render.filepath = str(job["output"])

    cycles = scene.cycles
    cycles.samples = max(1, int(job.get("samples", 128)))
    if hasattr(cycles, "use_denoising"):
        cycles.use_denoising = bool(job.get("denoise", True))
    if hasattr(cycles, "use_adaptive_sampling"):
        cycles.use_adaptive_sampling = True
    if hasattr(cycles, "adaptive_threshold"):
        cycles.adaptive_threshold = _option(job, "noise_threshold", 0.01, 0.001, 0.2)
    if hasattr(cycles, "preview_samples"):
        cycles.preview_samples = min(cycles.samples, 32)
    if hasattr(cycles, "max_bounces"):
        cycles.max_bounces = max(1, int(job.get("bounces", 6)))
    if hasattr(cycles, "transparent_max_bounces"):
        cycles.transparent_max_bounces = max(4, int(job.get("transparent_bounces", 8)))

    # The neutral response keeps colored molecular surfaces more vivid than
    # AgX, while still rolling highlights off for a studio photograph look.
    profiles = {
        "NEUTRAL": ("Khronos PBR Neutral", "None"),
        "STUDIO": ("AgX", "AgX - Medium High Contrast"),
        "DIRECT": ("Standard", "None"),
    }
    profile = str(job.get("color_profile", "NEUTRAL")).upper()
    if profile not in profiles:
        raise ValueError("color_profile must be NEUTRAL, STUDIO, or DIRECT")
    transform, look = profiles[profile]
    try:
        scene.view_settings.view_transform = transform
        scene.view_settings.look = look
    except (TypeError, ValueError):
        print(f"[PyMOL GPU Ray] {transform} is unavailable; using AgX", flush=True)
        scene.view_settings.view_transform = "AgX"
        scene.view_settings.look = "AgX - Medium High Contrast"
    try:
        scene.view_settings.exposure = float(job.get("exposure", 0.0))
    except Exception:
        pass


def setup_depth_cue(job: dict, objects: list, camera) -> dict:
    """Follow PyMOL's clipping slab and linear depth-cue model.

    Compute the fade per shading sample into a VALUE AOV, using camera Z
    rather than radial distance. Compositing it later preserves occlusion,
    shadows, antialiasing and depth-of-field sampling.
    """
    cue = job.get("pymol_depth_cue") or {}
    near = float(cue.get("clip_near", camera.data.clip_start))
    far = float(cue.get("clip_far", camera.data.clip_end))
    if not math.isfinite(near) or not math.isfinite(far) or not 0 < near < far:
        raise ValueError("PyMOL clipping planes must be finite and satisfy 0 < near < far")
    camera.data.clip_start, camera.data.clip_end = near, far
    mode = str(job.get("fog", "AUTO")).upper()
    if mode not in {"AUTO", "OFF", "CUSTOM"}:
        raise ValueError("fog must be AUTO, OFF, or CUSTOM")
    if mode == "CUSTOM":
        start_fraction = _option(job, "fog_start", 45, 0, 99.9) / 100
        density = _option(job, "fog_strength", 1, 0, 5)
        enabled = density > 0
    else:
        start_fraction = float(cue.get("start", 0.45))
        density = float(cue.get("density", 1))
        enabled = mode == "AUTO" and bool(cue.get("enabled", False)) and density > 0
    result = {"enabled": enabled, "mode": mode, "clip_near": near, "clip_far": far}
    if not enabled:
        return result
    if not math.isfinite(start_fraction) or not math.isfinite(density):
        raise ValueError("PyMOL fog settings must be finite")
    start_fraction = max(0.0, min(0.9999, start_fraction))
    start = near + (far - near) * start_fraction
    end = start + (far - start) / density
    for name in (FOG_AOV, FOG_COVERAGE_AOV):
        aov = bpy.context.view_layer.aovs.get(name) or bpy.context.view_layer.aovs.add()
        aov.name = name
        aov.type = "VALUE"
    materials = {mat for obj in objects if obj.type == "MESH" for mat in obj.data.materials if mat is not None}
    for mat in materials:
        nodes, links = mat.node_tree.nodes, mat.node_tree.links
        for node in list(nodes):
            if node.name.startswith("_PyMOLFog") or node.label.startswith("_PyMOLFog"):
                nodes.remove(node)
        depth = nodes.new("ShaderNodeCameraData")
        depth.name = "_PyMOLFogDepth"
        ramp = nodes.new("ShaderNodeMapRange")
        ramp.name = "_PyMOLFogRamp"
        ramp.interpolation_type = "LINEAR"
        ramp.clamp = True
        ramp.inputs["From Min"].default_value = start
        ramp.inputs["From Max"].default_value = end
        ramp.inputs["To Min"].default_value = 0
        ramp.inputs["To Max"].default_value = 1
        output = nodes.new("ShaderNodeOutputAOV")
        output.label = "_PyMOLFogOutput"
        if hasattr(output, "aov_name"):
            output.aov_name = FOG_AOV
            output.name = "_PyMOLFogOutput"
        else:
            output.name = FOG_AOV
        links.new(depth.outputs["View Z Depth"], ramp.inputs["Value"])
        links.new(ramp.outputs["Result"], output.inputs["Value"])
        coverage = nodes.new("ShaderNodeOutputAOV")
        coverage.label = "_PyMOLFogCoverage"
        if hasattr(coverage, "aov_name"):
            coverage.aov_name = FOG_COVERAGE_AOV
            coverage.name = "_PyMOLFogCoverage"
        else:
            coverage.name = FOG_COVERAGE_AOV
        coverage.inputs["Value"].default_value = 1
    bpy.context.view_layer.update_render_passes()
    result.update(start=start, end=end, density=density,
                  output="alpha fade" if job.get("transparent", True) else "backdrop blend")
    return result


def _fog_composite(tree, image, render_layers, job):
    nodes, links = tree.nodes, tree.links
    coverage = nodes.new("ShaderNodeMath")
    coverage.operation = "MAXIMUM"
    coverage.inputs[1].default_value = 1e-8
    links.new(render_layers.outputs[FOG_COVERAGE_AOV], coverage.inputs[0])
    fraction = nodes.new("ShaderNodeMath")
    fraction.operation = "DIVIDE"
    fraction.use_clamp = True
    links.new(render_layers.outputs[FOG_AOV], fraction.inputs[0])
    links.new(coverage.outputs[0], fraction.inputs[1])
    visibility = nodes.new("ShaderNodeMath")
    visibility.operation = "SUBTRACT"
    visibility.inputs[0].default_value = 1
    links.new(fraction.outputs[0], visibility.inputs[1])
    alpha = nodes.new("ShaderNodeMath")
    alpha.operation = "MULTIPLY"
    alpha.use_clamp = True
    # AOVs include sample coverage but not material transparency. Normalize by
    # a separate coverage AOV, then multiply the image's existing alpha so fog
    # preserves transparent materials as well as antialiased/defocused edges.
    links.new(render_layers.outputs["Alpha"], alpha.inputs[0])
    links.new(visibility.outputs[0], alpha.inputs[1])
    straight = nodes.new("CompositorNodePremulKey")
    if "Type" in straight.inputs:
        straight.inputs["Type"].default_value = "To Straight"
    else:
        straight.mapping = "PREMUL_TO_STRAIGHT"
    links.new(image, straight.inputs["Image"])
    set_alpha = nodes.new("CompositorNodeSetAlpha")
    if "Type" in set_alpha.inputs:
        set_alpha.inputs["Type"].default_value = "Replace Alpha"
    else:
        set_alpha.mode = "REPLACE_ALPHA"
    links.new(straight.outputs["Image"], set_alpha.inputs["Image"])
    links.new(alpha.outputs[0], set_alpha.inputs["Alpha"])
    premultiplied = nodes.new("CompositorNodePremulKey")
    if "Type" in premultiplied.inputs:
        premultiplied.inputs["Type"].default_value = "To Premultiplied"
    else:
        premultiplied.mapping = "STRAIGHT_TO_PREMUL"
    links.new(set_alpha.outputs["Image"], premultiplied.inputs["Image"])
    result = premultiplied.outputs["Image"]
    if not job.get("transparent", True):
        over = nodes.new("CompositorNodeAlphaOver")
        background = over.inputs.get("Background")
        foreground = over.inputs.get("Foreground")
        if background is None:
            background, foreground = over.inputs[1], over.inputs[2]
        background.default_value = (*job.get("bg_rgb", [1, 1, 1])[:3], 1)
        links.new(result, foreground)
        result = over.outputs["Image"]
    return result


def setup_compositor(job: dict) -> None:
    scene = bpy.context.scene
    # Blender 5 moved scene compositing to a standalone node group and removed
    # both Scene.node_tree and the Composite node. Keep the Blender 4.x path.
    modern_compositor = hasattr(scene, "compositing_node_group")
    if modern_compositor:
        tree = bpy.data.node_groups.new("PyMOLCompositor", "CompositorNodeTree")
        scene.compositing_node_group = tree
        tree.interface.new_socket(name="Image", in_out="OUTPUT", socket_type="NodeSocketColor")
    else:
        scene.use_nodes = True
        tree = scene.node_tree
    nodes = tree.nodes
    links = tree.links
    nodes.clear()

    render_layers = nodes.new("CompositorNodeRLayers")
    bright = nodes.new("CompositorNodeBrightContrast")
    brightness_input = bright.inputs.get("Brightness")
    if brightness_input is None:
        brightness_input = bright.inputs["Bright"]
    brightness_input.default_value = float(job.get("brightness", 0.0))
    bright.inputs["Contrast"].default_value = float(job.get("contrast", 0.0))
    hsv = nodes.new("CompositorNodeHueSat")
    # Socket order changed in Blender 5 (Image is now first). Names work with
    # both layouts and prevent applying look controls to the wrong sockets.
    hsv.inputs["Hue"].default_value = 0.5
    hsv.inputs["Saturation"].default_value = max(0.0, float(job.get("saturation", 1.05)))
    hsv.inputs["Value"].default_value = 1.0
    composite = nodes.new("NodeGroupOutput" if modern_compositor else "CompositorNodeComposite")

    scene.render.use_compositing = True
    links.new(render_layers.outputs["Image"], bright.inputs["Image"])
    links.new(bright.outputs["Image"], hsv.inputs["Image"])
    image = hsv.outputs["Image"]
    if job.get("_resolved_fog", {}).get("enabled"):
        image = _fog_composite(tree, image, render_layers, job)
    links.new(image, composite.inputs["Image"])


def render_job(job: dict) -> dict:
    job = dict(job)
    dae = str(job["dae"])
    output = str(job["output"])
    Path(output).parent.mkdir(parents=True, exist_ok=True)

    device = configure_device(str(job.get("backend", "AUTO")))
    importer, objects, camera = import_scene(dae)
    if not objects:
        raise RuntimeError("The COLLADA scene contained no renderable mesh objects")
    emission_strength = float(job.get("emission_strength", 0.0))
    roughness = _option(job, "roughness", 0.34, 0.0, 1.0)
    if importer == "BLENDER_COLLADA":
        normalize_imported_materials(objects, 1.0, emission_strength, roughness)
    else:
        enhance_fallback_materials(objects, 1.0, emission_strength, roughness)
    smoothed_spheres = smooth_spheres(objects)
    if camera is None:
        raise RuntimeError("No camera was found in the exported PyMOL COLLADA scene")

    setup_render(job)
    fog = setup_depth_cue(job, objects, camera)
    job["_resolved_fog"] = fog
    setup_compositor(job)
    add_lighting(objects, camera, job.get("bg_rgb", [1.0, 1.0, 1.0]), bool(job.get("transparent", True)), job)
    bpy.context.scene.camera = camera
    depth_of_field = setup_depth_of_field(job, objects, camera)

    bpy.ops.render.render(write_still=True)
    if not Path(output).is_file():
        raise RuntimeError(f"Blender finished without creating {output}")
    return {
        "ok": True,
        "mode": "render",
        "output": output,
        "backend": device["backend"],
        "devices": device.get("devices", []),
        "blender": device.get("blender", _version_string()),
        "importer": importer,
        "object_count": len(objects),
        "smoothed_spheres": smoothed_spheres,
        "depth_of_field": depth_of_field,
        "depth_cue": fog,
        "color_transform": bpy.context.scene.view_settings.view_transform,
        "warning": device.get("warning"),
    }


def diagnose(backend: str) -> dict:
    d = configure_device(backend)
    d.update({"mode": "diagnose", "collada_importer": _collada_operator_available()})
    return d


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="PyMOL GPU Ray Blender backend")
    parser.add_argument("--job", help="Path to JSON render job")
    parser.add_argument("--diagnose", action="store_true", help="Only detect Cycles devices")
    parser.add_argument("--backend", default="AUTO", choices=["AUTO", "OPTIX", "CUDA", "CPU"])
    return parser.parse_args(argv)


def main() -> int:
    # Arguments for a Blender Python script follow a literal --.
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    args = parse_args(argv)
    try:
        if args.diagnose:
            emit(diagnose(args.backend))
            return 0
        if not args.job:
            raise ValueError("--job is required unless --diagnose is used")
        job = json.loads(Path(args.job).read_text(encoding="utf-8"))
        emit(render_job(job))
        return 0
    except Exception as exc:
        traceback.print_exc()
        emit({"ok": False, "error": str(exc), "type": type(exc).__name__, "blender": _version_string()})
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
