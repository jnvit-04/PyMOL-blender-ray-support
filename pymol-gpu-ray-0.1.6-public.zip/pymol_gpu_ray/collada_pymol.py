"""Small, dependency-free COLLADA reader tailored to PyMOL's exporter.

It intentionally supports the subset emitted by PyMOL: triangle meshes,
polylists, triangle strips, vertex normals/colors, material bindings, and
simple scene transforms. It is used only when Blender's legacy COLLADA
importer is unavailable (Blender 5+).
"""
from __future__ import annotations

from dataclasses import dataclass, field
import math
import xml.etree.ElementTree as ET
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

Vec3 = Tuple[float, float, float]
Vec4 = Tuple[float, float, float, float]
Mat4 = Tuple[Tuple[float, float, float, float], ...]


def _local(tag: str) -> str:
    return tag.rsplit('}', 1)[-1]


def _children(node: ET.Element, name: str) -> List[ET.Element]:
    return [c for c in node if _local(c.tag) == name]


def _child(node: ET.Element, name: str) -> Optional[ET.Element]:
    for c in node:
        if _local(c.tag) == name:
            return c
    return None


def _desc(node: ET.Element, name: str) -> Iterable[ET.Element]:
    for c in node.iter():
        if _local(c.tag) == name:
            yield c


def _floats(text: Optional[str]) -> List[float]:
    return [float(x) for x in (text or '').split()]


def _ints(text: Optional[str]) -> List[int]:
    return [int(x) for x in (text or '').split()]


def _identity() -> Mat4:
    return (
        (1.0, 0.0, 0.0, 0.0),
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 1.0, 0.0),
        (0.0, 0.0, 0.0, 1.0),
    )


def _matmul(a: Mat4, b: Mat4) -> Mat4:
    return tuple(
        tuple(sum(a[r][k] * b[k][c] for k in range(4)) for c in range(4))
        for r in range(4)
    )


def _translation(v: Sequence[float]) -> Mat4:
    m = [list(r) for r in _identity()]
    m[0][3], m[1][3], m[2][3] = v[:3]
    return tuple(tuple(r) for r in m)


def _scale(v: Sequence[float]) -> Mat4:
    m = [list(r) for r in _identity()]
    m[0][0], m[1][1], m[2][2] = v[:3]
    return tuple(tuple(r) for r in m)


def _rotation(v: Sequence[float]) -> Mat4:
    x, y, z, deg = v[:4]
    n = math.sqrt(x * x + y * y + z * z) or 1.0
    x, y, z = x / n, y / n, z / n
    a = math.radians(deg)
    c, s, t = math.cos(a), math.sin(a), 1.0 - math.cos(a)
    return (
        (t*x*x+c, t*x*y-s*z, t*x*z+s*y, 0.0),
        (t*x*y+s*z, t*y*y+c, t*y*z-s*x, 0.0),
        (t*x*z-s*y, t*y*z+s*x, t*z*z+c, 0.0),
        (0.0, 0.0, 0.0, 1.0),
    )


def _matrix_from_collada(values: Sequence[float]) -> Mat4:
    if len(values) != 16:
        raise ValueError('COLLADA matrix must contain 16 values')
    # COLLADA uses column vectors, but the XML <matrix> values are written
    # row-by-row (translation therefore appears in entries 4, 8 and 12 in
    # 1-based notation). Keep that layout as an ordinary row-major matrix.
    return tuple(tuple(values[r * 4 + c] for c in range(4)) for r in range(4))


@dataclass
class MaterialInfo:
    id: str
    opacity: float = 1.0


@dataclass
class GeometryData:
    id: str
    positions: List[Vec3] = field(default_factory=list)
    faces: List[Tuple[int, ...]] = field(default_factory=list)
    corner_normals: List[Vec3] = field(default_factory=list)
    corner_colors: List[Vec4] = field(default_factory=list)


@dataclass
class GeometryInstance:
    geometry_id: str
    matrix: Mat4
    material_id: Optional[str] = None


@dataclass
class CameraData:
    matrix: Mat4
    perspective: bool = True
    yfov_deg: float = 30.0
    ymag: float = 10.0
    znear: float = 0.1
    zfar: float = 10000.0


@dataclass
class SceneData:
    geometries: Dict[str, GeometryData]
    instances: List[GeometryInstance]
    materials: Dict[str, MaterialInfo]
    camera: Optional[CameraData]
    up_axis: str = 'Y_UP'


def _parse_source(source: ET.Element) -> Tuple[List[Tuple[float, ...]], int]:
    float_array = _child(source, 'float_array')
    if float_array is None:
        return [], 1
    vals = _floats(float_array.text)
    accessor = None
    tc = _child(source, 'technique_common')
    if tc is not None:
        accessor = _child(tc, 'accessor')
    stride = int(accessor.get('stride', '1')) if accessor is not None else 1
    count = int(accessor.get('count', str(len(vals) // stride))) if accessor is not None else len(vals) // stride
    return [tuple(vals[i*stride:(i+1)*stride]) for i in range(count)], stride


def _parse_geometry(geom: ET.Element) -> GeometryData:
    gid = geom.get('id') or 'geometry'
    mesh = _child(geom, 'mesh')
    if mesh is None:
        return GeometryData(gid)

    sources: Dict[str, List[Tuple[float, ...]]] = {}
    for src in _children(mesh, 'source'):
        sid = src.get('id')
        if sid:
            sources[sid] = _parse_source(src)[0]

    vertices_map: Dict[str, str] = {}
    for verts in _children(mesh, 'vertices'):
        vid = verts.get('id')
        if not vid:
            continue
        for inp in _children(verts, 'input'):
            if inp.get('semantic') == 'POSITION':
                vertices_map[vid] = inp.get('source', '').lstrip('#')

    # PyMOL geometries use one POSITION source. Keep that indexed directly.
    position_source = next((s for k, s in sources.items() if k.endswith('-positions')), None)
    if position_source is None and vertices_map:
        position_source = sources.get(next(iter(vertices_map.values())))
    positions: List[Vec3] = [tuple(v[:3]) for v in (position_source or [])]  # type: ignore[list-item]

    out = GeometryData(gid, positions=positions)

    def consume_primitive(prim: ET.Element, face_sizes: List[int], p_nodes: List[ET.Element]) -> None:
        inputs = []
        max_offset = 0
        for inp in _children(prim, 'input'):
            semantic = inp.get('semantic', '')
            source = inp.get('source', '').lstrip('#')
            offset = int(inp.get('offset', '0'))
            max_offset = max(max_offset, offset)
            if semantic == 'VERTEX':
                source = vertices_map.get(source, source)
                semantic = 'POSITION'
            inputs.append((semantic, source, offset))
        stride = max_offset + 1
        inp_by_sem = {sem: (src, off) for sem, src, off in inputs}

        pos_src, pos_off = inp_by_sem.get('POSITION', (None, 0))
        norm_src, norm_off = inp_by_sem.get('NORMAL', (None, 0))
        col_src, col_off = inp_by_sem.get('COLOR', (None, 0))
        p_positions = sources.get(pos_src or '', positions)
        normals = sources.get(norm_src or '', [])
        colors = sources.get(col_src or '', [])

        for pnode, expected_size in zip(p_nodes, face_sizes):
            vals = _ints(' '.join(pnode.itertext()))
            if not vals:
                continue
            corners = [vals[i:i+stride] for i in range(0, len(vals), stride)]
            if expected_size > 0:
                groups = [corners[i:i+expected_size] for i in range(0, len(corners), expected_size)]
            else:
                groups = [corners]
            for group in groups:
                if len(group) < 3:
                    continue
                face = []
                cn: List[Vec3] = []
                cc: List[Vec4] = []
                for c in group:
                    pi = c[pos_off]
                    face.append(pi)
                    if norm_src and norm_off < len(c) and c[norm_off] < len(normals):
                        n = normals[c[norm_off]]
                        cn.append(tuple(n[:3]))  # type: ignore[arg-type]
                    else:
                        cn.append((0.0, 0.0, 0.0))
                    if col_src and col_off < len(c) and c[col_off] < len(colors):
                        col = colors[c[col_off]]
                        rgba = tuple(col[:4]) if len(col) >= 4 else tuple(col[:3]) + (1.0,)
                        cc.append(rgba)  # type: ignore[arg-type]
                    else:
                        cc.append((1.0, 1.0, 1.0, 1.0))
                out.faces.append(tuple(face))
                out.corner_normals.extend(cn)
                out.corner_colors.extend(cc)

    for prim in mesh:
        typ = _local(prim.tag)
        if typ == 'triangles':
            pnodes = _children(prim, 'p')
            # One p can contain many triangles.
            for p in pnodes:
                vals = _ints(' '.join(p.itertext()))
                inputs = _children(prim, 'input')
                stride = max([int(i.get('offset', '0')) for i in inputs] + [0]) + 1
                tri_count = len(vals) // (stride * 3)
                consume_primitive(prim, [3] * tri_count, [p] * tri_count if tri_count == 1 else _split_p_nodes(p, stride * 3, tri_count))
        elif typ == 'polylist':
            vc = _child(prim, 'vcount')
            sizes = _ints(' '.join(vc.itertext())) if vc is not None else []
            pnodes = _children(prim, 'p')
            if len(pnodes) == 1 and sizes:
                inputs = _children(prim, 'input')
                stride = max([int(i.get('offset', '0')) for i in inputs] + [0]) + 1
                vals = _ints(' '.join(pnodes[0].itertext()))
                cursor = 0
                for size in sizes:
                    n = size * stride
                    fake = ET.Element('p')
                    fake.text = ' '.join(str(x) for x in vals[cursor:cursor+n])
                    consume_primitive(prim, [size], [fake])
                    cursor += n
            else:
                consume_primitive(prim, sizes or [0] * len(pnodes), pnodes)
        elif typ == 'tristrips':
            inputs = _children(prim, 'input')
            stride = max([int(i.get('offset', '0')) for i in inputs] + [0]) + 1
            for p in _children(prim, 'p'):
                vals = _ints(' '.join(p.itertext()))
                corners = [vals[i:i+stride] for i in range(0, len(vals), stride)]
                for i in range(len(corners) - 2):
                    tri = [corners[i], corners[i+1], corners[i+2]]
                    if i % 2:
                        tri[0], tri[1] = tri[1], tri[0]
                    fake = ET.Element('p')
                    fake.text = ' '.join(str(x) for c in tri for x in c)
                    consume_primitive(prim, [3], [fake])
    return out


def _split_p_nodes(p: ET.Element, ints_per_face: int, count: int) -> List[ET.Element]:
    vals = _ints(' '.join(p.itertext()))
    out = []
    for i in range(count):
        fake = ET.Element('p')
        fake.text = ' '.join(str(x) for x in vals[i*ints_per_face:(i+1)*ints_per_face])
        out.append(fake)
    return out


def _node_matrix(node: ET.Element) -> Mat4:
    m = _identity()
    for c in node:
        typ = _local(c.tag)
        vals = _floats(c.text)
        if typ == 'matrix' and len(vals) == 16:
            m = _matmul(m, _matrix_from_collada(vals))
        elif typ == 'translate' and len(vals) >= 3:
            m = _matmul(m, _translation(vals))
        elif typ == 'rotate' and len(vals) >= 4:
            m = _matmul(m, _rotation(vals))
        elif typ == 'scale' and len(vals) >= 3:
            m = _matmul(m, _scale(vals))
    return m


def _parse_materials(root: ET.Element) -> Dict[str, MaterialInfo]:
    effects: Dict[str, float] = {}
    for effect in _desc(root, 'effect'):
        eid = effect.get('id')
        if not eid:
            continue
        opacity = 1.0
        # PyMOL writes <transparency><float>opacity</float></transparency>.
        for tr in _desc(effect, 'transparency'):
            f = next(_desc(tr, 'float'), None)
            if f is not None and f.text:
                try:
                    opacity = max(0.0, min(1.0, float(f.text.strip())))
                except ValueError:
                    pass
                break
        effects[eid] = opacity

    mats: Dict[str, MaterialInfo] = {}
    for mat in _desc(root, 'material'):
        mid = mat.get('id')
        if not mid:
            continue
        inst = _child(mat, 'instance_effect')
        eid = inst.get('url', '').lstrip('#') if inst is not None else ''
        mats[mid] = MaterialInfo(mid, effects.get(eid, 1.0))
    return mats


def _parse_camera_def(root: ET.Element) -> Dict[str, dict]:
    defs: Dict[str, dict] = {}
    for cam in _desc(root, 'camera'):
        cid = cam.get('id')
        if not cid:
            continue
        perspective = next(_desc(cam, 'perspective'), None)
        ortho = next(_desc(cam, 'orthographic'), None)
        if perspective is not None:
            def textf(name: str, default: float) -> float:
                e = next(_desc(perspective, name), None)
                return float(e.text) if e is not None and e.text else default
            defs[cid] = dict(perspective=True, yfov_deg=textf('yfov', 30.0), ymag=10.0,
                             znear=textf('znear', 0.1), zfar=textf('zfar', 10000.0))
        elif ortho is not None:
            def textf2(name: str, default: float) -> float:
                e = next(_desc(ortho, name), None)
                return float(e.text) if e is not None and e.text else default
            defs[cid] = dict(perspective=False, yfov_deg=30.0, ymag=textf2('ymag', 10.0),
                             znear=textf2('znear', 0.1), zfar=textf2('zfar', 10000.0))
    return defs


def parse(path: str) -> SceneData:
    root = ET.parse(path).getroot()
    asset = next(_desc(root, 'asset'), None)
    up_axis = 'Y_UP'
    if asset is not None:
        ua = _child(asset, 'up_axis')
        if ua is not None and ua.text:
            up_axis = ua.text.strip()

    geometries = {g.get('id') or f'geom{i}': _parse_geometry(g)
                  for i, g in enumerate(_desc(root, 'geometry'))}
    materials = _parse_materials(root)
    camera_defs = _parse_camera_def(root)

    instances: List[GeometryInstance] = []
    camera: Optional[CameraData] = None
    for vs in _desc(root, 'visual_scene'):
        for node in _children(vs, 'node'):
            nm = _node_matrix(node)
            for ig in _children(node, 'instance_geometry'):
                gid = ig.get('url', '').lstrip('#')
                material_id = None
                im = next(_desc(ig, 'instance_material'), None)
                if im is not None:
                    material_id = im.get('target', '').lstrip('#') or None
                instances.append(GeometryInstance(gid, nm, material_id))
            ic = _child(node, 'instance_camera')
            if ic is not None:
                cid = ic.get('url', '').lstrip('#')
                cdef = camera_defs.get(cid, {})
                camera = CameraData(matrix=nm, **cdef)
        break

    if not instances:
        instances = [GeometryInstance(gid, _identity(), None) for gid in geometries]
    return SceneData(geometries, instances, materials, camera, up_axis)
