"""PyMOL GPU Ray — GPU-accelerated Cycles/OptiX rendering for stock PyMOL.

The plugin deliberately keeps PyMOL and Blender in separate processes. PyMOL
exports the visible scene as COLLADA; Blender/Cycles renders it using OptiX,
CUDA, or CPU without modifying PyMOL itself.
"""
from __future__ import annotations

import datetime as _dt
import glob
import json
import math
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import tempfile
import threading
import time
import traceback
import uuid
import webbrowser

from pymol import cmd

__version__ = "0.1.6"
__author__ = "PyMOL GPU Ray contributors"

_PACKAGE_DIR = Path(__file__).resolve().parent
_EDITION_FILE = _PACKAGE_DIR / "edition.json"
_EDITION = json.loads(_EDITION_FILE.read_text(encoding="utf-8"))["edition"] if _EDITION_FILE.is_file() else "dev"
if _EDITION not in {"public", "dev"}:
    raise RuntimeError("Invalid GPU Ray edition; reinstall the public or dev package")
_IS_DEV = _EDITION == "dev"
_COMMAND_BASE = "gpu_ray_dev" if _IS_DEV else "gpu_ray"
_MENU_NAME = "GPU Ray Tracer (Dev)" if _IS_DEV else "GPU Ray Tracer"
_BACKEND_SCRIPT = _PACKAGE_DIR / "blender_backend.py"
_CONFIG_DIR = Path.home() / ".pymol_gpu_ray"
_CONFIG_FILE = _CONFIG_DIR / ("config.json" if _IS_DEV else "config-public.json")
_RESULT_MARKER = "PYMOL_GPU_RAY_RESULT="
_JOBS: dict[str, dict] = {}
_DIALOG = None
_REGISTERED = False
_LAST_JOB_ID = ""


def _print(message: str) -> None:
    print(f"[PyMOL GPU Ray{' Dev' if _IS_DEV else ''}] {message}")


def _as_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    return str(value).strip().lower() not in {"", "0", "false", "off", "no", "none"}


def _load_config() -> dict:
    try:
        return json.loads(_CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        if not _IS_DEV:
            # Reuse only Blender discovery from the former developer config.
            # Fine controls must never leak into the public edition's defaults.
            try:
                legacy = json.loads((_CONFIG_DIR / "config.json").read_text(encoding="utf-8"))
                return {"blender": legacy["blender"]} if legacy.get("blender") else {}
            except Exception:
                pass
        return {}


def _save_config(**updates) -> None:
    cfg = _load_config()
    cfg.update({k: v for k, v in updates.items() if v is not None})
    try:
        _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        _CONFIG_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except Exception as exc:
        _print(f"warning: could not save preferences: {exc}")


def _candidate_blenders() -> list[str]:
    candidates: list[str] = []
    env = os.environ.get("PYMOL_GPU_RAY_BLENDER") or os.environ.get("BLENDER_PATH")
    if env:
        candidates.append(env)
    cfg = _load_config()
    if cfg.get("blender"):
        candidates.append(str(cfg["blender"]))
    on_path = shutil.which("blender")
    if on_path:
        candidates.append(on_path)

    system = platform.system()
    if system == "Windows":
        candidates.extend(sorted(
            glob.glob(r"C:\Program Files\Blender Foundation\Blender *\blender.exe"),
            reverse=True,
        ))
        local = os.environ.get("LOCALAPPDATA")
        if local:
            candidates.extend(sorted(
                glob.glob(str(Path(local) / "Programs" / "Blender Foundation" / "Blender *" / "blender.exe")),
                reverse=True,
            ))
    elif system == "Darwin":
        candidates.extend([
            "/Applications/Blender.app/Contents/MacOS/Blender",
            str(Path.home() / "Applications/Blender.app/Contents/MacOS/Blender"),
        ])
    else:
        candidates.extend(["/usr/bin/blender", "/usr/local/bin/blender", "/snap/bin/blender"])

    seen = set()
    result = []
    for item in candidates:
        if not item:
            continue
        p = os.path.expanduser(os.path.expandvars(str(item).strip().strip('"')))
        key = os.path.normcase(os.path.abspath(p)) if os.path.isabs(p) else p
        if key in seen:
            continue
        seen.add(key)
        if os.path.isfile(p) or shutil.which(p):
            result.append(os.path.abspath(p) if os.path.isfile(p) else str(shutil.which(p)))
    return result


def find_blender(explicit: str = "") -> str:
    if explicit:
        p = os.path.expanduser(os.path.expandvars(str(explicit).strip().strip('"')))
        if os.path.isfile(p):
            return os.path.abspath(p)
        resolved = shutil.which(p)
        if resolved:
            return resolved
        raise RuntimeError(f"Blender executable not found: {explicit}")
    candidates = _candidate_blenders()
    if candidates:
        return candidates[0]
    raise RuntimeError(
        "Blender was not found. Install Blender 4.2+ or 5.x, then set its path "
        "in Plugins > GPU Ray Tracer, or set PYMOL_GPU_RAY_BLENDER."
    )


def _bg_rgb() -> list[float]:
    try:
        value = cmd.get_setting_tuple("bg_rgb")
        # PyMOL returns (setting_type, tuple-of-values).
        vals = value[1] if isinstance(value, tuple) and len(value) > 1 else value
        if isinstance(vals, (tuple, list)) and len(vals) >= 3:
            return [float(vals[0]), float(vals[1]), float(vals[2])]
    except Exception:
        pass
    try:
        text = str(cmd.get("bg_rgb")).replace(",", " ")
        vals = [float(x) for x in text.split()]
        if len(vals) >= 3:
            return vals[:3]
    except Exception:
        pass
    return [0.0, 0.0, 0.0]


def _viewport_size() -> tuple[int, int]:
    """Return the actual molecular viewer dimensions, excluding PyMOL chrome."""
    try:
        width, height = (int(value) for value in cmd.get_viewport())
        if width > 0 and height > 0:
            return width, height
    except Exception:
        pass
    return 1920, 1080


def _render_dimensions(width=0, height=0) -> tuple[int, int]:
    width, height = int(width or 0), int(height or 0)
    if width < 0 or height < 0:
        raise ValueError("width and height must be positive, or 0 to use the viewer size")
    if not width or not height:
        viewer_width, viewer_height = _viewport_size()
        if not width and not height:
            width, height = viewer_width, viewer_height
        elif not width:
            width = max(1, round(height * viewer_width / viewer_height))
        else:
            height = max(1, round(width * viewer_height / viewer_width))
    if width > 32768 or height > 32768:
        raise ValueError("resolution is unreasonably large (>32768 px)")
    return width, height


def _look_settings(cfg: dict) -> dict:
    defaults = dict(brightness=0.0, contrast=0.0, saturation=1.05, exposure=0.0)
    old_defaults = dict(brightness=0.12, contrast=0.18, saturation=1.12, exposure=0.8)
    # Migrate the former factory look; keep deliberately customized values.
    if not cfg.get("look_version") and all(cfg.get(k, v) == v for k, v in old_defaults.items()):
        return defaults
    studio_defaults = dict(brightness=0.0, contrast=0.0, saturation=1.0, exposure=0.0)
    if cfg.get("look_version", 0) < 3 and all(cfg.get(k, v) == v for k, v in studio_defaults.items()):
        return defaults
    return {key: float(cfg.get(key, value)) for key, value in defaults.items()}


def _advanced_settings(**values) -> dict:
    """Normalize UI/command options before launching Blender or saving preferences."""
    ranges = {
        "focus_depth": (10.0, 0.0, 100.0),
        "light_angle": (0.0, -180.0, 180.0),
        "shadow_softness": (1.0, 0.25, 3.0),
        "fill_light": (1.0, 0.0, 3.0),
        "roughness": (0.34, 0.0, 1.0),
        "noise_threshold": (0.01, 0.001, 0.2),
    }
    result = {}
    for key, (default, low, high) in ranges.items():
        value = float(values.get(key, default))
        if not math.isfinite(value) or not low <= value <= high:
            raise ValueError(f"{key} must be between {low:g} and {high:g}")
        result[key] = value
    profile = str(values.get("color_profile", "NEUTRAL")).upper()
    if profile not in {"NEUTRAL", "STUDIO", "DIRECT"}:
        raise ValueError("color_profile must be NEUTRAL, STUDIO, or DIRECT")
    result["color_profile"] = profile
    return result


def _setting(name: str):
    try:
        return cmd.get(name)
    except Exception:
        return None


def _depth_cue_snapshot() -> dict:
    """Snapshot the viewer's fog and clipping settings alongside its geometry."""
    def number(name, default):
        try:
            value = float(_setting(name))
            return value if math.isfinite(value) else default
        except (TypeError, ValueError):
            return default
    setting = _setting("depth_cue")
    cue = {"enabled": True if setting is None else _as_bool(setting),
           "start": number("fog_start", 0.45), "density": number("fog", 1.0)}
    try:
        view = cmd.get_view()
        near, far = float(view[15]), float(view[16])
        if math.isfinite(near) and math.isfinite(far) and far > max(near, 0.0):
            cue.update(clip_near=max(near, 1e-4), clip_far=far)
    except (TypeError, ValueError, IndexError):
        pass
    return cue


def _restore_setting(name: str, value) -> None:
    if value is None:
        return
    try:
        cmd.set(name, value)
    except Exception:
        pass


def _export_collada(path: Path) -> None:
    if not hasattr(cmd, "get_collada"):
        raise RuntimeError(
            "This PyMOL build does not expose cmd.get_collada(). A PyMOL build "
            "with COLLADA support (libxml2) is required."
        )
    saved = {name: _setting(name) for name in (
        "collada_geometry_mode", "collada_export_lighting", "collada_background_box"
    )}
    try:
        # geometry_mode=1 is PyMOL's Blender-compatible polygon mode.
        try:
            cmd.set("collada_geometry_mode", 1)
        except Exception:
            pass
        try:
            cmd.set("collada_export_lighting", 0)
        except Exception:
            pass
        try:
            cmd.set("collada_background_box", 0)
        except Exception:
            pass
        dae = cmd.get_collada()
        if isinstance(dae, bytes):
            dae = dae.decode("utf-8", errors="replace")
        if not dae or "<COLLADA" not in str(dae):
            raise RuntimeError("PyMOL returned an empty or invalid COLLADA scene")
        path.write_text(str(dae), encoding="utf-8")
    finally:
        for name, value in saved.items():
            _restore_setting(name, value)


def _default_output() -> Path:
    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    return Path.cwd() / f"pymol_gpu_ray_{stamp}.png"


def _creation_flags() -> int:
    # Prevent a transient console window for Blender on Windows.
    return getattr(subprocess, "CREATE_NO_WINDOW", 0) if platform.system() == "Windows" else 0


def _parse_result(log: str) -> dict | None:
    result = None
    for line in log.splitlines():
        if line.startswith(_RESULT_MARKER):
            try:
                result = json.loads(line[len(_RESULT_MARKER):])
            except Exception:
                pass
    return result


_PROGRESS_PATTERNS = [
    re.compile(r"Rendered\s+(\d+)/(\d+)\s+Samples", re.I),
    re.compile(r"Sample\s+(\d+)/(\d+)", re.I),
    re.compile(r"Path Tracing Sample\s+(\d+)/(\d+)", re.I),
    re.compile(r"Rendered\s+(\d+)/(\d+)\s+Tiles", re.I),
    re.compile(r"Path Tracing Tile\s+(\d+)/(\d+)", re.I),
]


def _parse_progress_line(line: str):
    text = str(line).strip()
    lower = text.lower()
    phase = None
    message = None
    if "cycles" in lower or "sample" in lower or "tile" in lower or "rendered" in lower:
        phase = "rendering"
    elif "collada" in lower or "import" in lower or "mesh" in lower or "object" in lower:
        phase = "importing"
    elif "denois" in lower:
        phase = "denoising"
    elif "saved:" in lower or "writing" in lower or "compositing" in lower:
        phase = "saving"
    for rx in _PROGRESS_PATTERNS:
        m = rx.search(text)
        if not m:
            continue
        current = int(m.group(1))
        total = max(1, int(m.group(2)))
        pct = max(0, min(100, int(round((current / total) * 100))))
        message = f"{current}/{total}"
        return pct, phase or "rendering", message
    return None, phase, message


def _open_file(path: str) -> None:
    try:
        if platform.system() == "Windows":
            os.startfile(path)  # type: ignore[attr-defined]
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as exc:
        _print(f"render complete, but could not open image automatically: {exc}")


def _run_render(job_id: str, blender: str, job_path: Path, temp_dir: Path, open_image: bool) -> None:
    command = [
        blender, "--background", "--factory-startup",
        "--python", str(_BACKEND_SCRIPT), "--", "--job", str(job_path),
    ]
    state = _JOBS[job_id]
    try:
        state["status"] = "rendering"
        state["phase"] = "launching"
        state["progress"] = 0
        state["message"] = "Launching Blender…"
        state["started_at"] = time.time()
        proc = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=_creation_flags(),
            bufsize=1,
        )
        state["process"] = proc

        lines: list[str] = []
        result = None
        last_printed = -1
        if proc.stdout is not None:
            while True:
                line = proc.stdout.readline()
                if not line:
                    if proc.poll() is not None:
                        break
                    time.sleep(0.05)
                    continue
                lines.append(line)
                if line.startswith(_RESULT_MARKER):
                    try:
                        result = json.loads(line[len(_RESULT_MARKER):])
                    except Exception:
                        pass
                    continue
                pct, phase, message = _parse_progress_line(line)
                if phase:
                    state["phase"] = phase
                if message:
                    state["message"] = message
                if pct is not None:
                    state["progress"] = pct
                    if pct >= last_printed + 10 or pct in {1, 100}:
                        last_printed = pct
                        _print(f"job {job_id}: {pct}% ({state.get('phase', 'rendering')})")
        proc.wait()

        log = "".join(lines)
        state["log"] = log
        result = result or _parse_result(log) or {
            "ok": False,
            "error": f"Blender exited with code {proc.returncode} without returning a result",
        }
        state["result"] = result
        if proc.returncode == 0 and result.get("ok"):
            state["status"] = "complete"
            state["phase"] = "complete"
            state["progress"] = 100
            state["message"] = "Render complete"
            output = str(result.get("output", state["output"]))
            backend = result.get("backend", "unknown")
            importer = result.get("importer", "unknown")
            _print(f"render complete [{backend}; {importer}]: {output}")
            if result.get("warning"):
                _print(f"warning: {result['warning']}")
            if open_image:
                _open_file(output)
            shutil.rmtree(temp_dir, ignore_errors=True)
        else:
            state["status"] = "failed"
            state["phase"] = "failed"
            err = result.get("error", f"Blender exited with code {proc.returncode}")
            state["message"] = err
            _print(f"render FAILED: {err}")
            _print(f"temporary files kept for diagnosis: {temp_dir}")
            tail = "\n".join(log.splitlines()[-25:])
            if tail:
                _print("Blender log tail:\n" + tail)
    except Exception as exc:
        state["status"] = "failed"
        state["phase"] = "failed"
        state["result"] = {"ok": False, "error": str(exc)}
        state["message"] = str(exc)
        state["log"] = traceback.format_exc()
        _print(f"render FAILED: {exc}")
        _print(f"temporary files kept for diagnosis: {temp_dir}")


def gpu_ray(
    width=0,
    height=0,
    samples=128,
    backend="AUTO",
    denoise=1,
    transparent=1,
    output="",
    blender="",
    open_image=1,
    wait=0,
    bounces=6,
    brightness=0.0,
    contrast=0.0,
    saturation=1.05,
    exposure=0.0,
    dof=0,
    fstop=0.02,
    focus_depth=10,
    light_angle=0,
    shadow_softness=1.0,
    fill_light=1.0,
    roughness=0.34,
    color_profile="NEUTRAL",
    noise_threshold=0.01,
    fog="AUTO",
    fog_start=45,
    fog_strength=1.0,
):
    """Render the current PyMOL scene with Blender Cycles GPU ray tracing.

    Examples
    --------
    gpu_ray_dev
    gpu_ray_dev 3840, 2160, 128
    gpu_ray_dev backend=OPTIX, transparent=1
    gpu_ray_dev output=figure.png, samples=256, wait=1
    gpu_ray_dev brightness=0.2, contrast=0.25, saturation=1.15
    """
    width, height = _render_dimensions(width, height)
    samples, bounces = int(samples), int(bounces)
    brightness = float(brightness)
    contrast = float(contrast)
    saturation = float(saturation)
    exposure = float(exposure)
    fstop = float(fstop)
    if not math.isfinite(fstop) or not 0.01 <= fstop <= 128.0:
        raise ValueError("fstop must be between 0.01 and 128")
    if samples < 1:
        raise ValueError("samples must be at least 1")
    if not 1 <= bounces <= 32:
        raise ValueError("bounces must be between 1 and 32")
    advanced = _advanced_settings(focus_depth=focus_depth, light_angle=light_angle,
                                 shadow_softness=shadow_softness, fill_light=fill_light,
                                 roughness=roughness, color_profile=color_profile,
                                 noise_threshold=noise_threshold)
    fog = str(fog).upper()
    if fog not in {"AUTO", "OFF", "CUSTOM"}:
        raise ValueError("fog must be AUTO, OFF, or CUSTOM")
    fog_start, fog_strength = float(fog_start), float(fog_strength)
    if not math.isfinite(fog_start) or not 0 <= fog_start <= 99.9:
        raise ValueError("fog_start must be between 0 and 99.9 percent")
    if not math.isfinite(fog_strength) or not 0 <= fog_strength <= 5:
        raise ValueError("fog_strength must be between 0 and 5")
    backend = str(backend).upper()
    if backend not in {"AUTO", "OPTIX", "CUDA", "CPU"}:
        raise ValueError("backend must be AUTO, OPTIX, CUDA, or CPU")

    blender_exe = find_blender(str(blender))
    _save_config(blender=blender_exe, backend=backend, brightness=brightness, contrast=contrast,
                 saturation=saturation, exposure=exposure, look_version=3,
                 transparent=_as_bool(transparent), dof=_as_bool(dof), fstop=fstop,
                 bounces=bounces, fog=fog, fog_start=fog_start, fog_strength=fog_strength, **advanced)

    out = Path(str(output)).expanduser() if str(output).strip() else _default_output()
    if not out.is_absolute():
        out = (Path.cwd() / out).resolve()
    if out.suffix.lower() != ".png":
        out = out.with_suffix(".png")
    out.parent.mkdir(parents=True, exist_ok=True)

    temp_dir = Path(tempfile.mkdtemp(prefix="pymol_gpu_ray_"))
    dae = temp_dir / "scene.dae"
    job_path = temp_dir / "job.json"
    try:
        _print("exporting visible PyMOL scene…")
        _export_collada(dae)
        job = {
            "schema": 1,
            "dae": str(dae),
            "output": str(out),
            "width": width,
            "height": height,
            "samples": samples,
            "bounces": bounces,
            "backend": backend,
            "denoise": _as_bool(denoise),
            "transparent": _as_bool(transparent),
            "bg_rgb": [1.0, 1.0, 1.0],
            "plugin_version": __version__,
            "brightness": brightness,
            "contrast": contrast,
            "saturation": saturation,
            "exposure": exposure,
            "emission_strength": 0.0,
            "dof": _as_bool(dof),
            "fstop": fstop,
            "fog": fog,
            "fog_start": fog_start,
            "fog_strength": fog_strength,
            "pymol_depth_cue": _depth_cue_snapshot(),
            "edition": _EDITION,
            **advanced,
        }
        job_path.write_text(json.dumps(job, indent=2), encoding="utf-8")
    except Exception:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise

    global _LAST_JOB_ID
    job_id = uuid.uuid4().hex[:8]
    _JOBS[job_id] = {
        "id": job_id,
        "status": "queued",
        "phase": "queued",
        "progress": 0,
        "message": "Queued",
        "output": str(out),
        "temp_dir": str(temp_dir),
        "result": None,
        "log": "",
        "started_at": None,
    }
    _LAST_JOB_ID = job_id
    _print(
        f"job {job_id}: {width}×{height}, {samples} spp, {backend}; output: {out}"
    )

    if _as_bool(wait):
        _run_render(job_id, blender_exe, job_path, temp_dir, _as_bool(open_image))
    else:
        thread = threading.Thread(
            target=_run_render,
            args=(job_id, blender_exe, job_path, temp_dir, _as_bool(open_image)),
            name=f"pymol-gpu-ray-{job_id}",
            daemon=True,
        )
        _JOBS[job_id]["thread"] = thread
        thread.start()
        _print(f"rendering in background; use {_COMMAND_BASE}_status {job_id} to check it")
    return str(out)


def _public_gpu_ray(width=0, height=0, samples=128, backend="AUTO", denoise=1,
                    transparent=1, output="", blender="", open_image=1, wait=0):
    """Render with the public studio preset, automatic PyMOL fog and viewer size."""
    return gpu_ray(width, height, samples, backend, denoise, transparent, output,
                   blender, open_image, wait)


def gpu_ray_status(job_id=""):
    """Print status for one render job, or all jobs in this PyMOL session."""
    jid = str(job_id).strip() or _LAST_JOB_ID
    jobs = [_JOBS[jid]] if jid and jid in _JOBS else list(_JOBS.values())
    if jid and not jobs:
        _print(f"unknown job: {jid}")
        return None
    if not jobs:
        _print("no GPU Ray jobs have been started in this PyMOL session")
        return None
    for state in jobs:
        elapsed = ""
        if state.get("started_at"):
            elapsed = f" | {max(0, int(time.time() - state['started_at']))} s"
        progress = state.get("progress")
        pct = f" | {progress}%" if isinstance(progress, int) else ""
        phase = state.get("phase") or state['status']
        _print(f"{state['id']}: {state['status']} | {phase}{pct}{elapsed} — {state['output']}")
        if state.get("message") and state["message"] not in {"Queued", "Render complete"}:
            _print(f"  note: {state['message']}")
        result = state.get("result") or {}
        if state["status"] == "failed" and result.get("error"):
            _print(f"  error: {result['error']}")
    return jobs[-1].get("status") if len(jobs) == 1 else None


def gpu_ray_diagnose(backend="AUTO", blender=""):
    """Check Blender, Cycles, and OptiX/CUDA availability without rendering."""
    backend = str(backend).upper()
    blender_exe = find_blender(str(blender))
    _save_config(blender=blender_exe, backend=backend)
    command = [
        blender_exe, "--background", "--factory-startup",
        "--python", str(_BACKEND_SCRIPT), "--",
        "--diagnose", "--backend", backend,
    ]
    _print(f"diagnosing {backend} with {blender_exe}")
    proc = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=_creation_flags(),
        timeout=90,
    )
    result = _parse_result(proc.stdout)
    if not result:
        tail = "\n".join(proc.stdout.splitlines()[-25:])
        raise RuntimeError(f"Blender diagnostics failed without a result.\n{tail}")
    if not result.get("ok"):
        raise RuntimeError(str(result.get("error", "Cycles diagnostics failed")))
    device_names = ", ".join(
        f"{d.get('name')} ({d.get('type')})" for d in result.get("devices", []) if d.get("enabled")
    ) or "none"
    _print(
        f"Blender {result.get('blender')} | backend={result.get('backend')} | "
        f"enabled devices: {device_names}"
    )
    if result.get("warning"):
        _print(f"warning: {result['warning']}")
    importer = "legacy Blender importer available" if result.get("collada_importer") else "bundled PyMOL COLLADA parser"
    _print(f"COLLADA path: {importer}")
    return result


def _register_commands() -> None:
    global _REGISTERED
    if _REGISTERED:
        return
    cmd.extend(_COMMAND_BASE, gpu_ray if _IS_DEV else _public_gpu_ray)
    cmd.extend(_COMMAND_BASE + "_status", gpu_ray_status)
    cmd.extend(_COMMAND_BASE + "_diagnose", gpu_ray_diagnose)
    cmd.extend(_COMMAND_BASE + "_gui", show_gui)
    _REGISTERED = True


def _active_job_state() -> dict | None:
    if _LAST_JOB_ID and _LAST_JOB_ID in _JOBS:
        return _JOBS[_LAST_JOB_ID]
    running = [j for j in _JOBS.values() if j.get("status") in {"queued", "rendering"}]
    if running:
        return running[-1]
    if _JOBS:
        return list(_JOBS.values())[-1]
    return None


def show_gui():
    """Show the compact GPU Ray Tracer dialog."""
    global _DIALOG
    try:
        from pymol.Qt import QtCore, QtWidgets
    except Exception as exc:
        raise RuntimeError(f"PyMOL Qt UI is unavailable: {exc}")

    class Dialog(QtWidgets.QDialog):
        def __init__(self, parent=None):
            super().__init__(parent)
            self.setWindowTitle(f"{_MENU_NAME} {__version__}")
            self.setMinimumWidth(520)
            self.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)

            cfg = _load_config()
            look = _look_settings(cfg)
            root = QtWidgets.QVBoxLayout(self)
            intro = QtWidgets.QLabel(
                "GPU ray tracing for the current PyMOL scene via Blender Cycles. "
                "AUTO prefers OptiX, then CUDA. Follows PyMOL clipping and depth fog."
            )
            intro.setWordWrap(True)
            root.addWidget(intro)

            form = QtWidgets.QFormLayout()
            root.addLayout(form)

            path_row = QtWidgets.QHBoxLayout()
            self.blender = QtWidgets.QLineEdit()
            detected = _candidate_blenders()
            self.blender.setText(str(cfg.get("blender") or (detected[0] if detected else "")))
            browse_blender = QtWidgets.QPushButton("Browse…")
            browse_blender.clicked.connect(self.pick_blender)
            path_row.addWidget(self.blender, 1)
            path_row.addWidget(browse_blender)
            form.addRow("Blender", path_row)

            self.backend = QtWidgets.QComboBox()
            self.backend.addItems(["AUTO", "OPTIX", "CUDA", "CPU"])
            preferred = str(cfg.get("backend", "AUTO")).upper()
            idx = self.backend.findText(preferred)
            self.backend.setCurrentIndex(max(0, idx))
            form.addRow("Backend", self.backend)

            resolution = QtWidgets.QHBoxLayout()
            viewer_width, viewer_height = _viewport_size()
            self.width = QtWidgets.QSpinBox(); self.width.setRange(1, 32768); self.width.setValue(viewer_width)
            self.height = QtWidgets.QSpinBox(); self.height.setRange(1, 32768); self.height.setValue(viewer_height)
            resolution.addWidget(self.width); resolution.addWidget(QtWidgets.QLabel("×")); resolution.addWidget(self.height)
            self.viewer_size = QtWidgets.QPushButton("Use viewer")
            self.viewer_size.setToolTip("Copy the current PyMOL molecular viewer's pixel dimensions")
            self.viewer_size.clicked.connect(self.use_viewer_size)
            resolution.addWidget(self.viewer_size)
            form.addRow("Resolution", resolution)

            self.samples = QtWidgets.QSpinBox()
            self.samples.setRange(1, 4096); self.samples.setValue(128); self.samples.setSingleStep(16)
            form.addRow("Samples", self.samples)

            options = QtWidgets.QHBoxLayout()
            self.denoise = QtWidgets.QCheckBox("Denoise"); self.denoise.setChecked(True)
            self.transparent = QtWidgets.QCheckBox("Transparent background")
            self.transparent.setChecked(bool(cfg.get("transparent", True)))
            self.open_image = QtWidgets.QCheckBox("Open when finished"); self.open_image.setChecked(True)
            options.addWidget(self.denoise); options.addWidget(self.transparent); options.addWidget(self.open_image)
            form.addRow("Options", options)

            if _IS_DEV:
                self.add_dev_controls(form, cfg, look)

            out_row = QtWidgets.QHBoxLayout()
            self.output = QtWidgets.QLineEdit(str(_default_output()))
            browse_output = QtWidgets.QPushButton("Browse…")
            browse_output.clicked.connect(self.pick_output)
            out_row.addWidget(self.output, 1); out_row.addWidget(browse_output)
            form.addRow("Output", out_row)

            self.status = QtWidgets.QLabel("Ready")
            self.status.setWordWrap(True)
            root.addWidget(self.status)

            self.progress = QtWidgets.QProgressBar()
            self.progress.setRange(0, 100)
            self.progress.setValue(0)
            self.progress.setFormat("Idle")
            root.addWidget(self.progress)

            self.timer = QtCore.QTimer(self)
            self.timer.setInterval(700)
            self.timer.timeout.connect(self.refresh_progress)

            buttons = QtWidgets.QHBoxLayout()
            self.install = QtWidgets.QPushButton("Get Blender")
            self.diagnose = QtWidgets.QPushButton("Diagnose")
            close = QtWidgets.QPushButton("Close")
            render = QtWidgets.QPushButton("Render")
            render.setDefault(True)
            buttons.addWidget(self.install)
            buttons.addStretch(1)
            buttons.addWidget(self.diagnose)
            buttons.addWidget(close)
            buttons.addWidget(render)
            root.addLayout(buttons)

            self.install.clicked.connect(lambda: webbrowser.open("https://www.blender.org/download/"))
            self.diagnose.clicked.connect(self.run_diagnose)
            close.clicked.connect(self.close)
            render.clicked.connect(self.run_render)

        def add_dev_controls(self, form, cfg, look):
            appearance = QtWidgets.QHBoxLayout()
            self.brightness = QtWidgets.QDoubleSpinBox(); self.brightness.setRange(-2.0, 2.0); self.brightness.setSingleStep(0.05); self.brightness.setDecimals(2); self.brightness.setValue(look["brightness"])
            self.contrast = QtWidgets.QDoubleSpinBox(); self.contrast.setRange(-2.0, 2.0); self.contrast.setSingleStep(0.05); self.contrast.setDecimals(2); self.contrast.setValue(look["contrast"])
            self.saturation = QtWidgets.QDoubleSpinBox(); self.saturation.setRange(0.0, 3.0); self.saturation.setSingleStep(0.05); self.saturation.setDecimals(2); self.saturation.setValue(look["saturation"])
            appearance.addWidget(QtWidgets.QLabel("Brightness")); appearance.addWidget(self.brightness)
            appearance.addWidget(QtWidgets.QLabel("Contrast")); appearance.addWidget(self.contrast)
            appearance.addWidget(QtWidgets.QLabel("Saturation")); appearance.addWidget(self.saturation)
            form.addRow("Look", appearance)

            exposure_row = QtWidgets.QHBoxLayout()
            self.exposure = QtWidgets.QDoubleSpinBox(); self.exposure.setRange(-2.0, 4.0); self.exposure.setSingleStep(0.05); self.exposure.setDecimals(2); self.exposure.setValue(look["exposure"])
            exposure_row.addWidget(self.exposure)
            exposure_row.addWidget(QtWidgets.QLabel("(global exposure)"))
            form.addRow("Exposure", exposure_row)

            self.advanced_toggle = QtWidgets.QToolButton()
            self.advanced_toggle.setText("Advanced")
            self.advanced_toggle.setCheckable(True)
            self.advanced_toggle.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
            self.advanced_toggle.setArrowType(QtCore.Qt.RightArrow)
            form.addRow(self.advanced_toggle)
            self.advanced = QtWidgets.QWidget()
            advanced_layout = QtWidgets.QVBoxLayout(self.advanced)
            advanced_layout.setContentsMargins(0, 0, 0, 0)

            def field(name, low, high, value, step=0.05, decimals=2, suffix="", tooltip=""):
                spin = QtWidgets.QDoubleSpinBox()
                spin.setRange(low, high); spin.setDecimals(decimals); spin.setSingleStep(step)
                spin.setValue(float(cfg.get(name, value)))
                spin.setSuffix(suffix); spin.setMaximumWidth(88); spin.setToolTip(tooltip)
                return spin

            def row(*items):
                layout = QtWidgets.QHBoxLayout()
                for item in items:
                    layout.addWidget(QtWidgets.QLabel(item) if isinstance(item, str) else item)
                layout.addStretch(1)
                advanced_layout.addLayout(layout)

            self.dof = QtWidgets.QCheckBox("Depth of field")
            self.dof.setChecked(bool(cfg.get("dof", False)))
            self.dof.setToolTip("Focus a chosen percentage into the visible system's depth")
            self.fstop = field("fstop", 0.01, 128, 0.02, step=0.01, decimals=3,
                               tooltip="Smaller f-stop gives more blur; larger values keep more depth sharp")
            self.focus_depth = field("focus_depth", 0, 100, 10, step=5, decimals=0, suffix="%",
                                     tooltip="0% = front surface; 10% = slightly inside; 100% = back surface")
            self.fstop.setEnabled(self.dof.isChecked())
            self.focus_depth.setEnabled(self.dof.isChecked())
            self.dof.toggled.connect(self.fstop.setEnabled)
            self.dof.toggled.connect(self.focus_depth.setEnabled)
            row(self.dof, "F-stop", self.fstop, "Focus depth", self.focus_depth)

            self.fog = QtWidgets.QComboBox()
            for label, token in (("Match PyMOL", "AUTO"), ("Off", "OFF"), ("Custom", "CUSTOM")):
                self.fog.addItem(label, token)
            self.fog.setCurrentIndex(max(0, self.fog.findData(cfg.get("fog", "AUTO"))))
            self.fog_start = field("fog_start", 0, 99.9, 45, step=5, decimals=1, suffix="%",
                                   tooltip="Where fog starts within the PyMOL near/far clipping range")
            self.fog_strength = field("fog_strength", 0, 5, 1, step=0.1, suffix="×",
                                      tooltip="Fog density; 1 reaches full fade at the far clipping plane")
            self.fog_start.setEnabled(self.fog.currentData() == "CUSTOM")
            self.fog_strength.setEnabled(self.fog.currentData() == "CUSTOM")
            self.fog.currentIndexChanged.connect(self.update_fog_controls)
            row("Depth fog", self.fog, "Start", self.fog_start, "Strength", self.fog_strength)

            self.light_angle = field("light_angle", -180, 180, 0, step=15, decimals=0, suffix="°",
                                     tooltip="Rotate the studio lights around the camera axis")
            self.shadow_softness = field("shadow_softness", 0.25, 3, 1, step=0.25, suffix="×",
                                         tooltip="Larger light sources give softer shadows and broader highlights")
            self.fill_light = field("fill_light", 0, 3, 1, step=0.1, suffix="×",
                                    tooltip="Brighten shadowed faces; 0 removes the fill light")
            row("Light angle", self.light_angle, "Softness", self.shadow_softness, "Fill", self.fill_light)

            self.roughness = field("roughness", 0, 1, 0.34,
                                   tooltip="Lower = glossy; higher = matte. Does not change geometry or transparency")
            self.color_profile = QtWidgets.QComboBox()
            for label, token in (("Natural color", "NEUTRAL"), ("Soft studio", "STUDIO"), ("Direct color", "DIRECT")):
                self.color_profile.addItem(label, token)
            self.color_profile.setCurrentIndex(max(0, self.color_profile.findData(cfg.get("color_profile", "NEUTRAL"))))
            self.color_profile.setToolTip("Natural color keeps stronger hues; Soft studio is the 0.1.4 look; Direct color uses Standard")
            row("Roughness", self.roughness, "Color response", self.color_profile)

            self.bounces = QtWidgets.QSpinBox()
            self.bounces.setRange(1, 32); self.bounces.setValue(int(cfg.get("bounces", 6)))
            self.bounces.setMaximumWidth(65)
            self.bounces.setToolTip("Maximum light bounces; raise for complex or transparent scenes")
            self.noise_threshold = field("noise_percent", 0.1, 20, float(cfg.get("noise_threshold", 0.01)) * 100,
                                         step=0.1, decimals=1, suffix="%",
                                         tooltip="Lower = cleaner but slower; Samples remains the maximum per pixel")
            self.reset_advanced = QtWidgets.QPushButton("Reset advanced")
            self.reset_advanced.clicked.connect(self.reset_advanced_settings)
            row("Bounces", self.bounces, "Noise limit", self.noise_threshold, self.reset_advanced)

            form.addRow(self.advanced)
            self.advanced.hide()
            self.advanced_toggle.toggled.connect(self.toggle_advanced)

        def pick_blender(self):
            path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Select Blender executable", self.blender.text())
            if path:
                self.blender.setText(path)

        def use_viewer_size(self):
            width, height = _viewport_size()
            self.width.setValue(width)
            self.height.setValue(height)

        def toggle_advanced(self, expanded):
            self.advanced.setVisible(expanded)
            self.advanced_toggle.setArrowType(QtCore.Qt.DownArrow if expanded else QtCore.Qt.RightArrow)
            self.adjustSize()

        def reset_advanced_settings(self):
            self.dof.setChecked(False)
            for widget, value in ((self.fstop, 0.02), (self.focus_depth, 10), (self.light_angle, 0),
                                  (self.shadow_softness, 1), (self.fill_light, 1), (self.roughness, 0.34),
                                  (self.bounces, 6), (self.noise_threshold, 1)):
                widget.setValue(value)
            self.color_profile.setCurrentIndex(0)
            self.fog.setCurrentIndex(0)
            self.fog_start.setValue(45)
            self.fog_strength.setValue(1)

        def update_fog_controls(self):
            custom = self.fog.currentData() == "CUSTOM"
            self.fog_start.setEnabled(custom)
            self.fog_strength.setEnabled(custom)

        def pick_output(self):
            path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Render to PNG", self.output.text(), "PNG image (*.png)")
            if path:
                self.output.setText(path)

        def refresh_progress(self):
            state = _active_job_state()
            if not state:
                self.progress.setValue(0)
                self.progress.setFormat("Idle")
                return
            progress = int(state.get("progress") or 0)
            phase = state.get("phase") or state.get("status", "idle")
            if state.get("status") == "failed":
                self.progress.setValue(min(100, max(0, progress)))
                self.progress.setFormat(f"Failed — {phase}")
                self.status.setText(f"Render failed — {state.get('message', 'see console log')}")
                self.timer.stop()
                return
            if state.get("status") == "complete":
                self.progress.setValue(100)
                self.progress.setFormat("Complete")
                self.status.setText(f"Render complete → {state['output']}")
                self.timer.stop()
                return
            self.progress.setValue(min(100, max(0, progress)))
            self.progress.setFormat(f"{progress}% — {phase}")
            self.status.setText(f"{state['id']}: {phase}… {state.get('message', '')}")

        def run_diagnose(self):
            try:
                result = gpu_ray_diagnose(self.backend.currentText(), self.blender.text())
                devices = ", ".join(d.get("name", "GPU") for d in result.get("devices", []) if d.get("enabled"))
                self.status.setText(f"OK — {result.get('backend')} on {devices or 'CPU'}")
            except Exception as exc:
                self.status.setText(f"Diagnostic failed: {exc}")
                QtWidgets.QMessageBox.critical(self, "GPU Ray diagnostics", str(exc))

        def run_render(self):
            try:
                options = dict(width=self.width.value(), height=self.height.value(), samples=self.samples.value(),
                               backend=self.backend.currentText(), denoise=int(self.denoise.isChecked()),
                               transparent=int(self.transparent.isChecked()), output=self.output.text(),
                               blender=self.blender.text(), open_image=int(self.open_image.isChecked()), wait=0)
                if _IS_DEV:
                    options.update(bounces=self.bounces.value(), brightness=self.brightness.value(),
                                   contrast=self.contrast.value(), saturation=self.saturation.value(), exposure=self.exposure.value(),
                                   dof=int(self.dof.isChecked()), fstop=self.fstop.value(),
                                   focus_depth=self.focus_depth.value(), light_angle=self.light_angle.value(),
                                   shadow_softness=self.shadow_softness.value(), fill_light=self.fill_light.value(),
                                   roughness=self.roughness.value(), color_profile=self.color_profile.currentData(),
                                   noise_threshold=self.noise_threshold.value() / 100,
                                   fog=self.fog.currentData(), fog_start=self.fog_start.value(), fog_strength=self.fog_strength.value())
                path = (gpu_ray if _IS_DEV else _public_gpu_ray)(**options)
                self.status.setText(f"Rendering in background → {path}")
                self.progress.setValue(1)
                self.progress.setFormat("Starting…")
                self.timer.start()
            except Exception as exc:
                self.status.setText(f"Could not start render: {exc}")
                QtWidgets.QMessageBox.critical(self, "GPU Ray Tracer", str(exc))

    try:
        parent = None
        _DIALOG = Dialog(parent)
        _DIALOG.show()
        _DIALOG.raise_()
        _DIALOG.activateWindow()
    except Exception:
        _DIALOG = None
        raise
    return _DIALOG


def __init_plugin__(app=None):
    """PyMOL plugin entry point."""
    _register_commands()
    try:
        from pymol.plugins import addmenuitemqt
        addmenuitemqt(_MENU_NAME, show_gui)
    except Exception as exc:
        _print(f"commands loaded, but menu registration failed: {exc}")


# Also register commands when the module is imported manually with `run`/Python.
_register_commands()
