# PyMOL GPU Ray

Render your current PyMOL view with Blender on the GPU.

1. Install [Blender 4.2 or newer](https://www.blender.org/download/).
2. In PyMOL, open **Plugin → Plugin Manager → Install New Plugin** and select
   `pymol-gpu-ray-0.1.6-public.zip`.
3. Restart PyMOL, then open **Plugin → GPU Ray Tracer**.
4. Click **Render**. If Blender isn't detected, select it with **Browse**.

The PNG uses your viewer's dimensions and a transparent background by default.

Basic commands:

- `gpu_ray` — render the current view.
- `gpu_ray_gui` — open the plugin window.
- `gpu_ray_status` — check render progress.
- `gpu_ray_diagnose` — check Blender and GPU setup.
